#include "SurveyClass.h"
SurveyClass::SurveyClass(){
    this->members=new LinkedList();
}
SurveyClass::SurveyClass(const SurveyClass &other) {
    this->members=new LinkedList(*other.members);

}
SurveyClass::SurveyClass(SurveyClass &&other) {
    this->members=new LinkedList(*other.members);
    other.~SurveyClass();
}
SurveyClass& SurveyClass::operator=(const SurveyClass &list) {
    this->~SurveyClass();
    this->members=new LinkedList(*list.members);
    return *this;
}
SurveyClass& SurveyClass::operator=(SurveyClass &&list) {
    this->~SurveyClass();
    this->members=new LinkedList(*list.members);
    list.~SurveyClass();
    return *this;
}
SurveyClass::~SurveyClass() {
//    delete this->members->head;
    delete this->members;
}
void SurveyClass::handleNewRecord(string _name, float _amount) {
    if(this->members->length==0){
        this->members->pushTail(_name,_amount);
        return;
    }
    Node* current=this->members->head;
    while(current->next!=0&&current->name!=_name){
        current=current->next;
    }
    if(current->name==_name){
        this->members->updateNode(_name,_amount);
    }else{
        this->members->pushTail(_name,_amount);
    }
}
float SurveyClass::calculateAverageExpense() {
    float sum=0;
    Node* current=this->members->head;
    for(int i=0;i<this->members->length;i++){
        sum+=current->amount;
        current=current->next;
    }
    sum=(int((sum/this->members->length)*100));
    sum=sum/100;
    return sum;
}
float SurveyClass::calculateMaximumExpense() {
    if(this->members->length==0){
        return 0;
    }
    float max=this->members->head->amount;
    Node* current=this->members->head;
    for(int i=0;i<this->members->length;i++){
        if(current->amount>max){
            max=current->amount;
        }
        current=current->next;
    }
    return max;
}
float SurveyClass::calculateMinimumExpense() {
    if(this->members->length==0){
        return 0;
    }
    float min=this->members->head->amount;
    Node* current=this->members->head;
    for(int i=0;i<this->members->length;i++){
        if(current->amount<min){
            min=current->amount;
        }
        current=current->next;
    }
    return min;
}