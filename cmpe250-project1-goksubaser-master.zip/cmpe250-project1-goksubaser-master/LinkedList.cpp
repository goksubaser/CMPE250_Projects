#include "LinkedList.h"
using namespace std;

LinkedList::LinkedList(){
    this->length=0;
    this->head=nullptr;
    this->tail=nullptr;
}
LinkedList::LinkedList(const LinkedList& list){
    this->length=list.length;
    this->head=new Node(*list.head);
    Node* current2=this->head;
    while(current2->next!=0){
        current2=current2->next;
    }
    this->tail=current2;
}
LinkedList& LinkedList:: operator=(const LinkedList& list){
    this->~LinkedList();
    this->length=list.length;
    this->head=new Node(*list.head);
    Node* current=this->head;
    while(current->next){
        current=current->next;
    }
    this->tail=current;
    return *this;

}
LinkedList::LinkedList(LinkedList&& list){
    this->length=list.length;
    this->head=new Node(*list.head);
    Node* current2=this->head;
    while(current2->next!=0){
        current2=current2->next;
    }
    this->tail=current2;
    list.~LinkedList();
}
LinkedList& LinkedList:: operator=(LinkedList&& list){
    this->~LinkedList();
    this->length=list.length;
    this->head=new Node(*list.head);
    Node* current=this->head;
    while(current->next){
        current=current->next;
    }
    this->tail=current;
    list.~LinkedList();
    return *this;
}
void LinkedList::pushTail(string _name, float _amount){
    if(this->length==0){
        this->tail=new Node(_name,_amount);
        this->tail->next=0;
        this->head=this->tail;
        length++;
    }else{
        this->tail->next=new Node(_name,_amount);
        this->tail=this->tail->next;
        length++;
    }
}
LinkedList::~LinkedList(){
    delete head;
    this->length=0;
}
void LinkedList::updateNode(string _name, float _amount){
    Node* current=this->head;
    while(current->next!=0&&current->name!=_name){
        current=current->next;
    }
    if(current->name==_name){
        current->amount=_amount;
    }
};

