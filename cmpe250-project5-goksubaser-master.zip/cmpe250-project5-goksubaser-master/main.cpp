#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

string text;
vector<string> words;
vector<long long int> wordHashes;
vector<vector<long long int>> hashTable;
long long int longestWordSize;
vector<long long int> solutionsOfIndexes;
long long int modulo;
vector<bool> wordSizesBool;
vector<long long int> powersOf31;
vector<long long int> wordSizes;
long long int line;
long long int textSize;

void HashMeBaby(){
    for(int i=1;i<=longestWordSize;i++){
        if(wordSizesBool[i]){
            long long int firstHash=0;
            for(int k=0; k<i; k++){
                firstHash=(firstHash+((text[k]-96)*powersOf31[i-k-1])%modulo)%modulo;
            }
            hashTable[i][0]=firstHash%modulo;
            for(int j=1; j<textSize+1-i;j++){
                    hashTable[i][j]=(((((hashTable[i][j-1])-((text[j-1]-96)*powersOf31[i-1])%modulo)+modulo)*31)%modulo);
                    hashTable[i][j]=((hashTable[i][j]+(text[j+i-1]-96))%modulo);
            }
        }
    }
    wordHashes=vector<long long int> (line,0);
    for(int i=0; i<line;i++){
        long long int hashTemp=0;
        for(int j=0; j<wordSizes[i]; j++){
            hashTemp+=((words[i][j]-96)*powersOf31[words[i].length()-j-1])%modulo;
        }
        wordHashes[i]=hashTemp%modulo;
    }
}
long long int FindItBaby(long long int index){
    if(index==text.size()){
        return 1;
    }else if(solutionsOfIndexes[index]!=0){
        return solutionsOfIndexes[index];
    }else if(index<solutionsOfIndexes.size()){
        for(int i=0; i<wordHashes.size(); i++){
            if(hashTable[wordSizes[i]][index]==wordHashes[i]){
                if(words[i]==text.substr(index,wordSizes[i])) {
                    solutionsOfIndexes[index] += FindItBaby(index + wordSizes[i]) % modulo;
                }
            }
        }
        solutionsOfIndexes[index]=solutionsOfIndexes[index]%modulo;
        return solutionsOfIndexes[index];
    }else{
        return 0;
    }
}

int main(int argc, char* argv[]) {


    ios_base::sync_with_stdio(false);
    // below reads the input file
    // in your next projects, you will implement that part as well
    if (argc != 3) {
        cout << "Run the code with the following command: ./project1 [input_file] [output_file]" << endl;
        return 1;
    }

    cout << "input file: " << argv[1] << endl;
    cout << "output file: " << argv[2] << endl;
    // here, perform the input operation. in other words,
    // read the file named <argv[1]>
    ifstream infile(argv[1]);

    infile>>text;


    infile>>line;

    wordSizesBool=vector<bool>(1005);
    wordSizes=vector<long long int>(line);
    words=vector<string>(line);
    textSize=text.length();
    longestWordSize=0;
    for(int i=0; i<line ;i++){
        infile>>words[i];
        wordSizesBool[words[i].size()]=true;
        wordSizes[i]=words[i].size();
        if(longestWordSize<words[i].size()){
            longestWordSize=words[i].size();
        }
    }

    infile.close();
    modulo=1;
    for(int i=0; i<9; i++){
        modulo=modulo*10;
    }
    modulo+=7;
    powersOf31=vector<long long int> (longestWordSize,0);
    powersOf31[0]=1;
    for(int i=1; i<longestWordSize; i++){
        powersOf31[i]=powersOf31[i-1]*31%modulo;
    }

    hashTable=vector<vector<long long int>>(longestWordSize+1,vector<long long int>(text.size(),-1));
    HashMeBaby();

    solutionsOfIndexes=vector<long long int>(text.size()+1,0);
    long long int y=FindItBaby(0);
    cout<<y<<endl;
    ofstream offile;
    offile.open(argv[2]);
//    int size=9;
//    for(int i=0; i<size; i++){
//        offile<<"a";
//    }
//    offile<<endl<<size<<endl;
//    for(int i=0; i<size; i++){
//        for(int j=0; j<i+1; j++){
//            offile<<"a";
//        }
//        offile<<endl;
//    }
    offile<<y<<endl;

    offile.close();

    return 0;
};