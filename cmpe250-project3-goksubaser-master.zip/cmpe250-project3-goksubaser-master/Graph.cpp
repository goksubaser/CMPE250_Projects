#include <iostream>
#include <vector>
#include <stack>
using namespace std;

class Graph {
public:
    vector<vector<int>> adjList;
    vector<vector<int>> sccAdjList;
    vector<bool> sccHasParent;
    int index=1;
    stack<int> S;
    vector<int> indexOfNodes;
    vector<int> lowLinks;
    vector<bool> onStack;
    int sccIndex=0;
    vector<int> sccIndexOfNodes;
    int size;
    vector<int> sccRoot;
    int p=-1;
    int count=0;
    vector<int> whichPiggies;

    Graph(int size){
        this->size=size;
        adjList.resize(size+5);
        indexOfNodes.resize(size+5);
        lowLinks.resize(size+5);
        onStack=vector<bool>(size+5);
        sccIndexOfNodes.resize(size+5);
        sccRoot.resize(size+5);
    }

    void strongconnect(int x) {
        indexOfNodes[x]=this->index;
        lowLinks[x]=this->index;
        this->index++;
        S.push(x);
        onStack[x]=true;

        for(int y:adjList[x]){
            if(indexOfNodes[y]==0){
                strongconnect(y);
                lowLinks[x]=min(lowLinks[y],lowLinks[x]);
            }
            if(onStack[y]){
                lowLinks[x]=min(lowLinks[x],lowLinks[y]);
            }
        }
        if(lowLinks[x]==indexOfNodes[x]){
            this->sccIndex++;
            sccIndexOfNodes[x]=this->sccIndex;
            sccRoot[sccIndex] =x;
            int temp;
            do{
                temp=S.top();
                S.pop();
                onStack[temp]=false;
                sccIndexOfNodes[temp]=this->sccIndex;

            }while(indexOfNodes[temp]!=indexOfNodes[x]);
        }

    }

    void tarjan(){
        for(int x=1;x<=size;x++){
            if(indexOfNodes[x]==0){
                strongconnect(x);
            }
        }
        sccAdjList.resize(sccIndex+1);//sıkıntı çıkabilir?
        sccHasParent=vector<bool>(sccIndex+1);
    }

    void createSAL(){
        int a=-1;
        for(vector<int> x:adjList){
            a++;
            if(indexOfNodes[a]!=0) {
                for (int y:x) {
                    if(indexOfNodes[y]!=0) {
                        if (sccIndexOfNodes[a] != sccIndexOfNodes[y]) {
                            sccAdjList[sccIndexOfNodes[a]].push_back(sccIndexOfNodes[y]);
                        }
                    }
                }
            }
        }
        for(vector<int> x:sccAdjList){
            for(int y:x){
                sccHasParent[y]=true;
            }
        }
        //p=0;
        for(bool x:sccHasParent){
            p++;
            if(!x){
                if(p!=0) {
                    count++;
                    whichPiggies.push_back(sccRoot[p]);
                }
            }
        }
    }
};