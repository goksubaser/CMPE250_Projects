#include <iostream>
#include <vector>
#include <fstream>
#include "Graph.cpp"
using namespace std;

int main(int argc, char* argv[]) {
    ios_base::sync_with_stdio(false);
    // below reads the input file
    if (argc != 3) {
        cout << "Run the code with the following command: ./project1 [input_file] [output_file]" << endl;
        return 1;
    }

    cout << "input file: " << argv[1] << endl;
    cout << "output file: " << argv[2] << endl;



    // here, perform the input operation. in other words,
    // read the file named <argv[1]>
    ifstream infile(argv[1]);
    int a;
    infile>>a;
    Graph* g=new Graph(a);
    for(int i=1; i<=a; i++){
        int b;
        infile>>b;
        for(int j=0; j<b;j++){
            int c;
            infile>>c;
            g->adjList[i].push_back(c);

        }
    }
    g->tarjan();
    g->createSAL();
    ofstream offile;
    offile.open(argv[2]);
    offile<<g->count<<" ";
    for(int i=0;i<g->whichPiggies.size();i++){
        offile<<g->whichPiggies[i]<<" ";
    }
    offile.close();
    return 0;
}
