#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;
vector<vector<int>> costMatrix;
vector<vector<int>> matrix;
vector<vector<bool>> visitedMatrix;


class customCompare {
public:
    bool operator()(vector<int> x, vector<int> y) {
        return x[2] > y[2];
    }
};

void buildCostMatrix(int startX, int startY, int finishX, int finishY){
    priority_queue<vector<int>, vector<vector<int>>, customCompare> q;
    costMatrix[startY][startX]=0;
    vector<int> startingPoint;
    startingPoint.push_back(startY);
    startingPoint.push_back(startX);
    startingPoint.push_back(0);
    q.push(startingPoint);
    while(q.size()>0){
        vector<int> temp;
        temp=q.top();
        if(temp[0]==finishY&&temp[1]==finishX){
            break;
        }
        q.pop();
        if(!visitedMatrix[temp[0]][temp[1]]){
            visitedMatrix[temp[0]][temp[1]] = true;
            if (temp[1] + 1 <= matrix[0].size() - 1 && !visitedMatrix[temp[0]][temp[1] + 1]) {//sağ
                costMatrix[temp[0]][temp[1] + 1] = min(costMatrix[temp[0]][temp[1] + 1],
                                                       max(abs(matrix[temp[0]][temp[1] + 1] - matrix[temp[0]][temp[1]]),
                                                           temp[2]));
                vector<int> temp2;
                temp2.push_back(temp[0]);
                temp2.push_back(temp[1] + 1);
                temp2.push_back(costMatrix[temp[0]][temp[1] + 1]);
                q.push(temp2);
            }
            if (temp[0] - 1 >= 0 && !visitedMatrix[temp[0] - 1][temp[1]]) {//yukarı
                costMatrix[temp[0] - 1][temp[1]] = min(costMatrix[temp[0] - 1][temp[1]],
                                                       max(abs(matrix[temp[0] - 1][temp[1]] - matrix[temp[0]][temp[1]]),
                                                           temp[2]));
                vector<int> temp2;
                temp2.push_back(temp[0] - 1);
                temp2.push_back(temp[1]);
                temp2.push_back(costMatrix[temp[0] - 1][temp[1]]);
                q.push(temp2);
            }
            if (temp[1] - 1 >= 0 && !visitedMatrix[temp[0]][temp[1] - 1]) {//sol
                costMatrix[temp[0]][temp[1] - 1] = min(costMatrix[temp[0]][temp[1] - 1],
                                                       max(abs(matrix[temp[0]][temp[1] - 1] - matrix[temp[0]][temp[1]]),
                                                           temp[2]));
                vector<int> temp2;
                temp2.push_back(temp[0]);
                temp2.push_back(temp[1] - 1);
                temp2.push_back(costMatrix[temp[0]][temp[1] - 1]);
                q.push(temp2);

            }
            if (temp[0] + 1 <= matrix[0].size() - 1 && !visitedMatrix[temp[0] + 1][temp[1]]) {//aşağı
                costMatrix[temp[0] + 1][temp[1]] = min(costMatrix[temp[0] + 1][temp[1]],
                                                       max(abs(matrix[temp[0] + 1][temp[1]] - matrix[temp[0]][temp[1]]),
                                                          temp[2]));
                vector<int> temp2;
                temp2.push_back(temp[0] + 1);
                temp2.push_back(temp[1]);
                temp2.push_back(costMatrix[temp[0] + 1][temp[1]]);
                q.push(temp2);

            }
        }
    }

}
int main(int argc, char* argv[]) {


    ios_base::sync_with_stdio(false);
    // below reads the input file
    if (argc != 3) {
        cout << "Run the code with the following command: ./project1 [input_file] [output_file]" << endl;
        return 1;
    }

    cout << "input file: " << argv[1] << endl;
    cout << "output file: " << argv[2] << endl;
    // here, perform the input operation. in other words,
    // read the file named <argv[1]>
    ifstream infile(argv[1]);
    int a;
    int b;
    infile>>a;
    infile>>b;
    matrix.resize(a);
    costMatrix.resize(a);
    visitedMatrix.resize(a);

    for(int i=0; i<a; i++){
        for(int j=0; j<b; j++){
            int x;
            infile>>x;
            matrix[i].push_back(x);
            costMatrix[i].push_back(1000000005);
            visitedMatrix[i].push_back(false);
        }
    }

    int x;
    infile>> x;
    int startY;
    infile>>startY;
    startY-=1;
    int startX;
    infile>>startX;
    startX-=1;
    int finishY;
    infile>>finishY;
    finishY-=1;
    int finishX;
    infile>>finishX;
    finishX-=1;
    infile.close();
    buildCostMatrix(startX,startY,finishX,finishY);
    ofstream offile;
    offile.open(argv[2]);
    offile<<costMatrix[finishY][finishX]<<endl;
    offile.close();

    return 0;
};
